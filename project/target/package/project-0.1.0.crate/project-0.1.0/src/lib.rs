pub fn print_function(start:i32, end:i32) {
    for index in start..end{
        println!("Counter {}",index );
    }
}